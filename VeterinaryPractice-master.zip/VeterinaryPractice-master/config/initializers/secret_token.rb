# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
VeterinaryPractice::Application.config.secret_token = '2b5dcadcdc00e841898ecc8f2bc9691204820001c5091dabb1945878ae38e089d99eda25bf60cbd69a0db5a57be89d6c4ab2350c714a1e1adc9c4bd9052c1179'
